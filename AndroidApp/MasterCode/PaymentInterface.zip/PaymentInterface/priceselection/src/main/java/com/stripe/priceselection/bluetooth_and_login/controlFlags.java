package com.stripe.priceselection.bluetooth_and_login;

/**
 * Created by Munifa on 2018-02-22
 */

public class controlFlags {
    public static boolean startCharging = false;
    public static boolean monitorConsumption = false;
    public static boolean goingToLogin = false;
    public static boolean connectionFailed = false;
}
