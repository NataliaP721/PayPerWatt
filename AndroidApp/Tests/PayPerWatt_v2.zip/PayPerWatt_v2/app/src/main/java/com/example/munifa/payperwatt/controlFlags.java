package com.example.munifa.payperwatt;

/**
 * Created by Munifa on 2018-02-22
 */

class controlFlags {
    static boolean startCharging = false;
    static boolean monitorConsumption = false;
}
