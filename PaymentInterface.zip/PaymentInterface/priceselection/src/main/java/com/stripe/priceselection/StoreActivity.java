package com.stripe.priceselection;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;
import com.stripe.android.PaymentConfiguration;

/**
 *
 */
public class StoreActivity
        extends AppCompatActivity
        implements StoreAdapter.TotalItemsChangedListener{

    /**
     *
     */
    private static final String PUBLISHABLE_KEY =
            "sk_test_Pr9JjZAMTijvQnaFc1F5bV5f";
    private FloatingActionButton mGoToCartButton;
    private StoreAdapter mStoreAdapter;

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);

        PaymentConfiguration.init(PUBLISHABLE_KEY);
        mGoToCartButton = findViewById(R.id.fab_checkout);
        mStoreAdapter = new StoreAdapter(this);
        ItemDivider dividerDecoration = new ItemDivider(this, R.drawable.item_divider);
        RecyclerView recyclerView = findViewById(R.id.rv_store_items);

        mGoToCartButton.hide();
        Toolbar myToolBar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolBar);

        RecyclerView.LayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.addItemDecoration(dividerDecoration);
        recyclerView.setAdapter(mStoreAdapter);

        mGoToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT > 9) {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                }
                URLConnect obj = new URLConnect();
                obj.GET();

                String response = obj.POST("token\t" + mStoreAdapter.mTotalOrdered);

                if (response.equals(mStoreAdapter.mTotalOrdered)) {
                    Toast.makeText(getApplicationContext(), "Server Authorized Payment", Toast.LENGTH_LONG).show();
                    //TO THE NEXT ACTIVITY
                }
            }
        });
    }

    /**
     *
     * @param totalItems
     */
    @Override
    public void onTotalItemsChanged(int totalItems) {
        if (totalItems > 0) {
            mGoToCartButton.show();
        } else {
            mGoToCartButton.hide();
        }
    }

    }
